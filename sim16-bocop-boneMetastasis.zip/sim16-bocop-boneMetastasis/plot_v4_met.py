#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  4 12:06:55 2019

@author: user
"""

import PyDSTool
import numpy as np
import pylab as plt
from mpl_toolkits.mplot3d import Axes3D
import sympy as sp
import csv

plt.rc('text', usetex=True)
plt.rc('font', family='serif')

# name of system
DSargs = PyDSTool.args(name='ode')

# death rate OBs (1/day) [SAME UNITS]
# bB: # bB: 1.2e-3 -- 6.2e1
#aBWpar = 1.2e-1

# Wnt production (???) [PAR * xW / xC * xT]
#'aW': 6.39e-9, # farhat

#aWpar = 2.0/499. # healthy

#aTpar = 1.0
#string_case = "v2_rem_normal"

#aTpar = 1.0
string_case = "dummie"

#---# HOMEOSTASIS
#bCpar = 6.4e-2
#bCTpar = 1.0e-1
#bTpar = 499. # farhat
##bBpar = 0.02 # komarova
#bBpar = 0.1 
#bWpar = 2.0 # buenzli

#---#
# sources
bCpar = 0.2 # 
bTpar = 499. # farhat
#bBpar = 0.02 # komarova
#bBpar = 1.8 # HOPF
bBpar = 0.02

# estimates
bCTpar = 2.0e-2
bWpar = 0.1 

##---# HOMEOSTASIS

#
aTpar = bTpar
aBWpar = bBpar
aWpar = bWpar*aTpar/bTpar

##--
#
#string_case = "osteoblastic"
#string_title = "osteoblastic lesion"
#
#KCpar = 0.0
#KBpar = 0.0
#aCMpar = 1.0e-1
#aMTpar = 3.0e-2

##---
#
#string_case = "osteoclastic"
#string_title = "osteoclastic lesion"
#
#KCpar = 0.0
#KBpar = 0.9
#aCMpar = 1.0e-1
#aMTpar = 3.0e-2

#---

string_case = "mixed"
string_title = "mixed lesion"

KCpar = 0.0
KBpar = 0.5
aCMpar = 2.0e-1
aMTpar = 3.0e-2

#--
#
#string_case = "osteoclastic2"
#string_title = "osteoclastic lesion2"
#
#KCpar = 0.9
#KBpar = 0.0
#aCMpar = 1.0e-1
#aMTpar = 3.0e-2

#---

#
#---# OSTEOPOROSIS
#string_case = "osteoporosis"
#string_title = "osteoporosis"
#
#aTpar = 0.5*bTpar
#
#aBWpar = bBpar
#aWpar = bWpar*aTpar/bTpar

#---#
## sources
#string_case = "oscillatory"
#string_title = "oscillatory remodeling"
#bCpar = 0.8 # 
#
#bTpar = 499. # farhat
#
##bBpar = 0.02 # komarova
##bBpar = 1.8 # HOPF
#bBpar = 0.48
#
## estimates
#bCTpar = 2.0e-2
#bWpar = 0.1 
#
#aBWpar = bBpar
#aTpar = bTpar
#aWpar = bWpar*aTpar/bTpar




#---#

# parameters
DSargs.pars = {
# diff from precursors (1/day) [PAR * xC * xB]
# 2e-1 -- 5.63e3
# 
# aC -> aC/xC xB -> *** aC = PAR * xC * xB ***
#'aC': 3.2e-1, # unit: mass**2 / day
'aC': bCpar + bCTpar, # unit: mass**2 / day
#'aC': 5.63e0, # unit: mass**2 / day
#'aC': 1.0e0, # unit: mass**2 / day

# death rate OCs (1/day) [SAME UNITS]
# bC: 6.4e-2 -- 2.0e0
#'bC': 3.0e-1, 
'bC': bCpar,
#'bC': 2.0e0,

# death by tgfb (1/day) [bCT = PAR / xT]
# 1.3e-1 (ross) -. 1.2e0 (farhat)
# bCT -> bCT*xT -> *** bCT = PAR / xT ***
'bCT': bCTpar,  # unit: 1/day * mass
#'bCT': 1.0e-2,  # unit: 1/day * mass
#'bCT': 1.2e0, # unit: 1/day * mass
#'bCT': 1.0e-5,  # unit: 1/day * mass

# promotion by wnt (1/day) [aBW = PAR / xW]
# farhat: OBp2 but not shown; assuming =OBp1=2.65e-1
# aBW -> aBW * xW -> *** aBW = PAR / xW ***
#'aBW': 2.65e-1, # unit: 1 / day * mass
#'aBW': 5.0e-1, # unit: 1 / day * mass
'aBW': aBWpar, # unit: 1 / day * mass

# death rate OBs (1/day) [SAME UNITS]
# bB: # bB: 1.2e-3 -- 6.2e1
# bB up -> frequency up
#'bB': 3.0e-1,
#'bB': 1.0e-2,
'bB': aBWpar,
#'bB': 6.2e1,

# TGF production (1/day) [PAR * xT / xC]
# TGF 7.1e-4 -- 2.14e-2
# aT -> aT * xC / xT -> aT = PAR * xT / xC
#'aT': 1.0, #pivonka2008 (same)
'aT': aTpar, #pivonka2008 (same)


# TGF elimination (1/day) [SAME UNITS]
# bT: 7.2e-1 -- 4.99e2
# bT up -> OBs up
#'bT': 2.0/aWpar, #--estimate--#
#'bT': 7.2e-1,
'bT': bTpar,

# Wnt production (???) [PAR * xW / xC * xT]
#'aW': 6.39e-9, # farhat
'aW': aWpar, #--estimate--#
#'aW': 1.0e-1, #--estimate--#

# Wnt elimination (1/day) [SAME UNITS]
'bW': bWpar, #farhat, buenzli (same)
#'bW': 5.0e-1, 

'KC': KCpar,
'KB': KBpar,

'aCM': aCMpar,

#'aM' : 2.3e-3, #farhat (check: logistic)
'aM' : 1.0e-3,
'KM' : 1.0,
#'aMT': 1.0e-1
'aMT': aMTpar
}

# model equations                   
DSargs.varspecs = {
'xC': '(1.0 - KC*xM/KM)*aC*xB^(-1.0) - bC*xC - bCT*xC*xT + aCM*xM',
'xB': 'aBW*xB*xW - bB*xB',
'xT': 'aT*xC - bT*xT',
'xW': '(1.0 - KB*xM/KM)*aW*xT*xC - bW*xW',
'xM': 'xM*(aM + aMT*xT)*(1.0 - xM/KM)'}

# baseline initial conditions
# homeo-osteo
#DSargs.ics      = {'xC': 0.5, 
#                   'xB': 0.2, 
#                   'xT': 0.0,
#                   'xW': 0.0,
#                   'xM': 1.0e-1}

# oscillatory
#DSargs.ics      = {'xC': 1.5, 
#                   'xB': 1.2, 
#                   'xT': 1.0,
#                   'xW': 0.0,
#                   'xM': 0.0e-1}

DSargs.ics      = {'xC': 1.0, 
                   'xB': 1.0, 
                   'xT': 1.0,
                   'xW': 1.0,
                   'xM': 0.1}

aC = DSargs.pars['aC']
bC = DSargs.pars['bC']
bCT = DSargs.pars['bCT']

aBW = DSargs.pars['aBW']
bB = DSargs.pars['bB']

aT = DSargs.pars['aT']
bT = DSargs.pars['bT']

aW = DSargs.pars['aW']
bW = DSargs.pars['bW']

xWeq = bB/aBW
xTeq = np.sqrt(bW*aT*xWeq/(aW*bT))
xCeq = bT*xTeq/aT
xBeq = aC/(xCeq*(bC+bCT*xTeq))

KC = DSargs.pars['KC']
KB = DSargs.pars['KB']
KM = DSargs.pars['KM']
aCM = DSargs.pars['aCM']

xWeq2 = bB/aBW
xTeq2 = np.sqrt(bW*aT*xWeq2/(aW*(1.0-KB)*bT))
xCeq2 = bT*xTeq2/aT
xBeq2 = aC/(xCeq2*(bC+bCT*xTeq2)-aCM)

eqs  = [xCeq,  xBeq,  xTeq,  xWeq,  0.0]
eqs2 = [xCeq2, xBeq2, xTeq2, xWeq2, 1.0]
print(eqs)
print(eqs2)
# time
DSargs.tdomain = [0,150]

# solve
ode  = PyDSTool.Generator.Vode_ODEsystem(DSargs)
traj = ode.compute('odeSol')
pd   = traj.sample(dt=0.1)

xM0  = pd['t']
xCM0 = pd['xC']
xBM0 = pd['xB']
xMM0 = pd['xM']

#%%
plt.close('all')

def extractMetExp_4ctrl():
    x  = []
    bis = []
    antitgf = []
    wnt = []
    chemo = []
    
    folderName = './sol06/'
    
    with open(folderName + 'discretization_times.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            x.append(float(row[0]))
    
    with open(folderName + 'bis.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            bis.append(float(row[0]))
    
    with open(folderName + 'antitgf.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            antitgf.append(float(row[0]))
            
    with open(folderName + 'wnt.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            wnt.append(float(row[0]))
            
    with open(folderName + 'chemo.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            chemo.append(float(row[0]))
            
    xC = []
    
    with open(folderName + 'xC.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xC.append(float(row[0]))
    
    xB = []
    
    with open(folderName + 'xB.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xB.append(float(row[0]))
    
    xT = []
    
    with open(folderName + 'xT.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xT.append(float(row[0]))
    
    xW = []
    
    with open(folderName + 'xW.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xW.append(float(row[0]))

    xM = []
    
    with open(folderName + 'xM.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xM.append(float(row[0]))
            
    return x, bis, antitgf, wnt, chemo, xC, xB, xT, xW, xM


x, bis, antitgf, wnt, chemo, xC, xB, xT, xW, xM = extractMetExp_4ctrl()

plt.figure(figsize=(8,3.5))

plt.subplot(2,4,1)
plt.plot(xM0,xCM0,':',color='#1f77b4',linewidth=1)
plt.plot(x,xC,'#1f77b4',linewidth=1)
plt.ylabel('OCs',fontsize=12)
plt.xticks([0, 150])
plt.xlabel('Time (days)',fontsize=12)
#plt.ylim([1,9])
#plt.yticks([1,5,9])

plt.subplot(2,4,2)
plt.plot(xM0,xBM0,':',color='#ff7f0e',linewidth=1)
plt.plot(x,xB,'#ff7f0e',linewidth=1)
plt.ylabel('OBs',fontsize=12)
plt.xticks([0, 150])
plt.xlabel('Time (days)',fontsize=12)
#plt.ylim([0,9])
#plt.yticks([0,4.5,9])

plt.subplot(2,4,3)
plt.plot(xM0,xMM0,':',color='#9467bd',linewidth=1)
plt.plot(x,xM,color='#9467bd',linewidth=1)
plt.ylabel('CCs',fontsize=12)
plt.xticks([0, 150])
plt.ylim([0,1])
plt.yticks([0,1])
plt.xlabel('Time (days)',fontsize=12)

plt.subplot(2,4,4)
plt.plot(x,[xx/yy for xx, yy in zip(xC, xB)],color='#393d42',linewidth=1)
plt.plot(xM0,[xx/yy for xx, yy in zip(xCM0, xBM0)],color='#393d42',linestyle='dotted',linewidth=1)
plt.xticks([0, 150])
plt.xlabel('Time (days)',fontsize=12)
#plt.xlim([2,7])
#plt.xticks([2,4.5,7])
#plt.ylim([0,9])
#plt.yticks([0,4.5,9])
plt.ylim([0.5,1.5])
plt.yticks([0.5,1,1.5])
plt.plot([0,150],[1,1],'k--',alpha=0.25)
plt.ylabel('OCs/OBs',fontsize=12)

plt.subplot(2,4,5)
plt.plot(x,bis,'k',linewidth=1)
#plt.ylim([0,0.05])
#plt.yticks([0.0, 0.025, 0.05])
plt.fill_between(x,bis,color='k',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('Bisphosphonate',fontsize=12)
plt.xticks([0, 150])
plt.ylim([-0.05, 0.5])
plt.yticks([0, 0.5], ['off','on'])
plt.xlabel('Time (days)',fontsize=12)
  
plt.subplot(2,4,6)
plt.plot(x,antitgf,'r',linewidth=1)
#plt.ylim([0,200])
#plt.yticks([0,100,200])
plt.fill_between(x,antitgf,color='r',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('Anti-TGFb',fontsize=12)
plt.xticks([0, 150])
plt.ylim([-100, 1000])
plt.yticks([0, 1000], ['off','on'])
plt.xlabel('Time (days)',fontsize=12)

plt.subplot(2,4,7)
plt.plot(x,wnt,'m',linewidth=1)
#plt.ylim([0,5])
#plt.yticks([0,2.5,5])
plt.fill_between(x,wnt,color='m',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('Wnt input',fontsize=12)
plt.xticks([0, 150])
plt.ylim([-0.1, 1])
plt.yticks([0, 1], ['off','on'])
plt.xlabel('Time (days)',fontsize=12)

plt.subplot(2,4,8)
plt.plot(x,chemo,'g',linewidth=1)
#plt.ylim([0,0.1])
#plt.yticks([0.00, 0.05, 0.1])
plt.fill_between(x,chemo,color='g',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('Chemotherapy',fontsize=12)
plt.xticks([0, 150])
plt.ylim([-0.05, 0.5])
plt.yticks([0, 0.5], ['off','on'])
plt.xlabel('Time (days)',fontsize=12)

plt.tight_layout()