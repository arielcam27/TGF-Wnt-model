import numpy as np
import matplotlib.pyplot as plt
import csv

plt.rc('text', usetex=True)
plt.rc('font', family='serif')

import PyDSTool

plt.rcParams['text.usetex'] = True

#---ODE Simulation---#



#--- BONE METASTASIS ---#
# name of system
DSargs = PyDSTool.args(name='ode')
#---#
# sources
bCpar = 0.2 # 
bTpar = 499. # farhat
#bBpar = 0.02 # komarova
#bBpar = 1.8 # HOPF
bBpar = 0.02

# estimates
bCTpar = 2.0e-2
bWpar = 0.1 

##---# HOMEOSTASIS
#string_case = "homeostasis"
#string_title = "homeostasis"
#
#aTpar = bTpar
#aBWpar = bBpar
#aWpar = bWpar*aTpar/bTpar

#
#---# OSTEOPOROSIS
string_case = "osteoporosis"
string_title = "osteoporosis"

aTpar = 0.5*bTpar

aBWpar = bBpar
aWpar = bWpar*aTpar/bTpar

#---#
## sources
#string_case = "oscillatory"
#string_title = "oscillatory remodeling"
#bCpar = 0.8 # 
#
#bTpar = 499. # farhat
#
##bBpar = 0.02 # komarova
##bBpar = 1.8 # HOPF
#bBpar = 0.48
#
## estimates
#bCTpar = 2.0e-2
#bWpar = 0.1 
#
#aBWpar = bBpar
#aTpar = bTpar
#aWpar = bWpar*aTpar/bTpar

#---#

# parameters
DSargs.pars = {
# diff from precursors (1/day) [PAR * xC * xB]
# 2e-1 -- 5.63e3
# 
# aC -> aC/xC xB -> *** aC = PAR * xC * xB ***
#'aC': 3.2e-1, # unit: mass**2 / day
'aC': bCpar + bCTpar, # unit: mass**2 / day
#'aC': 5.63e0, # unit: mass**2 / day
#'aC': 1.0e0, # unit: mass**2 / day

# death rate OCs (1/day) [SAME UNITS]
# bC: 6.4e-2 -- 2.0e0
#'bC': 3.0e-1, 
'bC': bCpar,
#'bC': 2.0e0,

# death by tgfb (1/day) [bCT = PAR / xT]
# 1.3e-1 (ross) -. 1.2e0 (farhat)
# bCT -> bCT*xT -> *** bCT = PAR / xT ***
'bCT': bCTpar,  # unit: 1/day * mass
#'bCT': 1.0e-2,  # unit: 1/day * mass
#'bCT': 1.2e0, # unit: 1/day * mass
#'bCT': 1.0e-5,  # unit: 1/day * mass

# promotion by wnt (1/day) [aBW = PAR / xW]
# farhat: OBp2 but not shown; assuming =OBp1=2.65e-1
# aBW -> aBW * xW -> *** aBW = PAR / xW ***
#'aBW': 2.65e-1, # unit: 1 / day * mass
#'aBW': 5.0e-1, # unit: 1 / day * mass
'aBW': aBWpar, # unit: 1 / day * mass

# death rate OBs (1/day) [SAME UNITS]
# bB: # bB: 1.2e-3 -- 6.2e1
# bB up -> frequency up
#'bB': 3.0e-1,
#'bB': 1.0e-2,
'bB': aBWpar,
#'bB': 6.2e1,

# TGF production (1/day) [PAR * xT / xC]
# TGF 7.1e-4 -- 2.14e-2
# aT -> aT * xC / xT -> aT = PAR * xT / xC
#'aT': 1.0, #pivonka2008 (same)
'aT': aTpar, #pivonka2008 (same)


# TGF elimination (1/day) [SAME UNITS]
# bT: 7.2e-1 -- 4.99e2
# bT up -> OBs up
#'bT': 2.0/aWpar, #--estimate--#
#'bT': 7.2e-1,
'bT': bTpar,

# Wnt production (???) [PAR * xW / xC * xT]
#'aW': 6.39e-9, # farhat
'aW': aWpar, #--estimate--#
#'aW': 1.0e-1, #--estimate--#

# Wnt elimination (1/day) [SAME UNITS]
'bW': bWpar, #farhat, buenzli (same)
#'bW': 5.0e-1, 

'KC': 0.9,
'KB': 0.0,

'aCM': 2.0e-1,

#'aM' : 2.3e-3, #farhat (check: logistic)
'aM' : 1.0e-3,
'KM' : 1.0,
#'aMT': 1.0e-1
'aMT': 3.0e-2
}

# model equations                   
DSargs.varspecs = {
'xC': 'aC*xB^(-1.0) - bC*xC - bCT*xC*xT',
'xB': 'aBW*xB*xW - bB*xB',
'xT': 'aT*xC - bT*xT',
'xW': 'aW*xT*xC - bW*xW'}

# baseline initial conditions
DSargs.ics      = {'xC': 2.0, 
                   'xB': 0.5, 
                   'xT': 1.0,
                   'xW': 1.0}

aC = DSargs.pars['aC']
bC = DSargs.pars['bC']
bCT = DSargs.pars['bCT']

aBW = DSargs.pars['aBW']
bB = DSargs.pars['bB']

aT = DSargs.pars['aT']
bT = DSargs.pars['bT']

aW = DSargs.pars['aW']
bW = DSargs.pars['bW']

xWeq = bB/aBW
xTeq = np.sqrt(bW*aT*xWeq/(aW*bT))
xCeq = bT*xTeq/aT
xBeq = aC/(xCeq*(bC+bCT*xTeq))

eqs = [xCeq, xBeq, xTeq, xWeq]
print(eqs)

# time
DSargs.tdomain = [0,150]

# solve
ode  = PyDSTool.Generator.Vode_ODEsystem(DSargs)
traj = ode.compute('odeSol')
pd   = traj.sample(dt=0.1)

xM0  = pd['t']
xCM0 = pd['xC']
xBM0 = pd['xB']

#%%
plt.close('all')

def extract_ctrl():
    x  = []
    bis = []
    tgf = []
    wnt = []
    
    folderName = './sol03/'
    
    with open(folderName + 'discretization_times.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            x.append(float(row[0]))
    
    with open(folderName + 'bis.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            bis.append(float(row[0]))
    
    with open(folderName + 'tgf.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            tgf.append(float(row[0]))
            
    with open(folderName + 'wnt.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            wnt.append(float(row[0]))
            
    xC = []
    
    with open(folderName + 'xC.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xC.append(float(row[0]))
    
    xB = []
    
    with open(folderName + 'xB.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xB.append(float(row[0]))
    
    xT = []
    
    with open(folderName + 'xT.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xT.append(float(row[0]))
    
    xW = []
    
    with open(folderName + 'xW.export','r') as csvfile:
        plots = csv.reader(csvfile)
        for row in plots:
            xW.append(float(row[0]))

            
    return x, bis, tgf, wnt, xC, xB, xT, xW


x, bis, tgf, wnt, xC, xB, xT, xW = extract_ctrl()

plt.figure(figsize=(6,3.5))

plt.subplot(2,3,1)
plt.plot(xM0,xCM0,':',color='#1f77b4',linewidth=1)
plt.plot(x,xC,'#1f77b4',linewidth=1)
plt.ylabel('OCs',fontsize=12)
plt.xticks([0, 150])
plt.xlabel('Time (days)',fontsize=12)
#plt.ylim([2,7])
#plt.yticks([2,4.5,7])
plt.subplots_adjust(wspace=0, hspace=0)

plt.subplot(2,3,2)
plt.plot(xM0,xBM0,':',color='#ff7f0e',linewidth=1)
plt.plot(x,xB,'#ff7f0e',linewidth=1)
plt.ylabel('OBs',fontsize=12)
plt.xticks([0, 150])
plt.xlabel('Time (days)',fontsize=12)
#plt.ylim([0,9])
#plt.yticks([0,4.5,9])
plt.subplots_adjust(wspace=0, hspace=0)

plt.subplot(2,3,3)
#plt.plot(xCM0,xBM0,':',color='b',alpha=0.5,linewidth=1)
plt.plot(x,[xx/yy for xx, yy in zip(xC, xB)],color='#393d42',linewidth=1)
plt.xticks([0, 150])
plt.xlabel('Time (days)',fontsize=12)
#plt.plot(xC[0],xB[0],'ro',linewidth=1)
#plt.xlim([2,7])
#plt.xticks([2,4.5,7])
plt.ylim([0,4])
plt.yticks([0,1,4])
plt.plot([0,150],[1,1],'k--',alpha=0.25)
plt.ylabel('OCs/OBs',fontsize=12)
plt.subplots_adjust(wspace=0, hspace=0)

plt.subplot(2,3,4)
plt.plot(x,bis,'k',linewidth=1)
#plt.ylim([0,0.5])
#plt.yticks([0.0, 0.25, 0.5])
#plt.ylim([0,0.01])
#plt.yticks([0.0, 0.005, 0.01])
plt.fill_between(x,bis,color='k',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('Bisphosphonate',fontsize=12)
plt.xticks([0, 150])
plt.ylim([-0.05, 0.5])
plt.yticks([0, 0.5], ['off','on'])
plt.xlabel('Time (days)',fontsize=12)
plt.subplots_adjust(wspace=0, hspace=0)

plt.subplot(2,3,5)
plt.plot(x,tgf,'c',linewidth=1)
#plt.ylim([0,100])
#plt.yticks([0, 50, 100])
plt.fill_between(x,tgf,color='c',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('TGF input',fontsize=12)
plt.xticks([0, 150])
plt.yticks([0, 1000], ['off','on'])
plt.ylim([-100, 1000])
plt.xlabel('Time (days)',fontsize=12)
plt.subplots_adjust(wspace=0, hspace=0)

plt.subplot(2,3,6)
plt.plot(x,wnt,'m',linewidth=1)
#plt.ylim([0,2])
#plt.yticks([0, 1, 2])
plt.fill_between(x,wnt,color='m',alpha=0.5)
plt.xlabel('Time (days)',fontsize=12)
plt.ylabel('Wnt input',fontsize=12)
plt.yticks([0, 1], ['off','on'])
plt.xticks([0, 150])
plt.ylim([-0.1,1])
plt.xlabel('Time (days)',fontsize=12)

plt.subplots_adjust(wspace=0, hspace=0)
plt.tight_layout()